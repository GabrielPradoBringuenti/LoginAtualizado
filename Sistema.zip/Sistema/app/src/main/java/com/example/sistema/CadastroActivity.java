package com.example.sistema;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.example.sistema.modelo.Usuario;

public class CadastroActivity extends AppCompatActivity {

    private EditText etNome;
    private EditText etEmail;
    private EditText etSenha;
    private Switch  sProfessor;
    private Button btCadastrar;
    //private FirebaseAuth mauth;
    private Usuario u;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        etNome = findViewById(R.id.etNome);
        etEmail = findViewById(R.id.etEmail);
        etSenha = findViewById(R.id.etSenha);
        sProfessor = findViewById(R.id.sProfessor);
        btCadastrar = findViewById(R.id.btCadastrar);
         //mAuth = FirebaseAuth.getInstance();
        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                recuperarDados();
                criarLogin();
            }
        });
    }

    private void criarLogin() {
        
    }

    private void recuperarDados() {

        if(etNome.getText().toString()=="" || etEmail.getText().toString()=="" || etSenha.getText().toString()=="" || ){

            Toast.makeText( this, "Você deve preencher todos os dados",Toast.LENGTH_LONG);
            
            
        }else {

            Usuario u = new Usuario();

            u = new Usuario();
            u.setNome(etNome.getText().toString());
            u.setEmail(etEmail.getText().toString());
            u.setSenha(etSenha.getText().toString());
            u.setProfessor(sProfessor.getShowText());

        }

    }
}